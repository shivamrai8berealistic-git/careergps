import Razorpay from 'razorpay';
import crypto from 'crypto';

let razorpayInstance: Razorpay | null = null;

export function getRazorpay() {
  if (razorpayInstance) return razorpayInstance;

  const keyId = process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;

  if (!keyId || !keySecret) {
    // During build time, we might not have these. 
    // We return a dummy or handle it if we are in build context.
    // However, the goal is to not call 'new Razorpay' until runtime.
    if (process.env.NODE_ENV === 'production' && !process.env.NEXT_PHASE) {
       console.warn('Razorpay keys missing in production runtime!');
    }
  }

  razorpayInstance = new Razorpay({
    key_id: keyId || 'dummy_key',
    key_secret: keySecret || 'dummy_secret',
  });

  return razorpayInstance;
}

export function verifyWebhookSignature(
  body: string,
  signature: string,
  secret: string
) {
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(body)
    .digest('hex');
  return expectedSignature === signature;
}

export async function createSubscription(userId: string, planId: string) {
  const razorpay = getRazorpay();
  
  // Map internal plan IDs to environment variable IDs
  const envKeyMap: Record<string, string | undefined> = {
    'plan_1m': process.env.RAZORPAY_PLAN_ID_1M,
    'plan_3m': process.env.RAZORPAY_PLAN_ID_3M,
    'plan_6m': process.env.RAZORPAY_PLAN_ID_6M,
  };

  const razorpayPlanId = envKeyMap[planId];

  if (!razorpayPlanId) {
    throw new Error(`Razorpay Plan ID for ${planId} is not configured in environment variables.`);
  }

  const subscription = await razorpay.subscriptions.create({
    plan_id: razorpayPlanId,
    customer_notify: 1,
    total_count: 120, // 10 years for recurring
    notes: {
      userId: userId,
      planType: planId
    },
  });

  return subscription;
}
