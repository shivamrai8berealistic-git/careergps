'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
    createUserWithEmailAndPassword, 
    GoogleAuthProvider, 
    signInWithPopup 
} from 'firebase/auth';
import { 
    getFirestore, 
    doc, 
    setDoc, 
    getDoc, 
    serverTimestamp 
} from 'firebase/firestore';
import { getApp } from 'firebase/app';
import { useAuth, useUser } from '@/firebase';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
    Card, 
    CardContent, 
    CardDescription, 
    CardHeader, 
    CardTitle 
} from '@/components/ui/card';
import { Rocket } from 'lucide-react';
import ReCAPTCHA from "react-google-recaptcha";
import { SITE_CONFIG } from "@/lib/config";

export default function SignupPage() {
  const auth = useAuth();
  const { user, isUserLoading } = useUser();
  const router = useRouter();
  const { toast } = useToast();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);

  // Redirect to dashboard if user is already logged in
  useEffect(() => {
    if (!isUserLoading && user) {
      router.push('/dashboard');
    }
  }, [user, isUserLoading, router]);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || !fullName) {
      toast({
        variant: "destructive",
        title: "Missing fields",
        description: "Please fill out all fields.",
      });
      return;
    }

    if (!captchaToken && SITE_CONFIG.security.recaptchaSiteKey) {
        toast({
            variant: "destructive",
            title: "Verification Required",
            description: "Please complete the reCAPTCHA to proceed.",
        });
        return;
    }
    
    setIsLoading(true);
    
    try {
      // 1. Create user in Firebase Authentication
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const newUser = userCredential.user;

      // 2. Create the user profile document in Firestore
      const firestore = getFirestore(getApp());
      const profileDocRef = doc(firestore, 'users', newUser.uid, 'profile', 'main-profile');
      
      const newProfile = {
        id: profileDocRef.id,
        userId: newUser.uid,
        fullName: fullName,
        email: newUser.email,
        role: 'user', // Default role
        yearsOfExperience: 0,
        currentOrLastJobTitle: "",
        keySkills: [],
        workModePreference: "remote",
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        profileCompletenessScore: 20
      };
      
      // 3. Save the document
      await setDoc(profileDocRef, newProfile);

      toast({
        title: "Account Created!",
        description: "Welcome to CareerPilot AI. You will be redirected.",
      });
      // Redirection is handled by the useEffect hook

    } catch (error: any) {
      let description = "An unexpected error occurred. Please try again.";
      if (error.code) {
          switch (error.code) {
              case 'auth/email-already-in-use':
                  description = "An account with this email address already exists. Please login instead.";
                  break;
              case 'auth/weak-password':
                  description = "The password is too weak. It must be at least 6 characters long.";
                  break;
              case 'auth/invalid-email':
                  description = "The email address is not valid. Please check and try again.";
                  break;
          }
      }
      toast({
        variant: "destructive",
        title: "Signup Failed",
        description: description,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const onCaptchaChange = (token: string | null) => {
    setCaptchaToken(token);
  };

  const handleGoogleSignup = async () => {
    setIsLoading(true);
    const provider = new GoogleAuthProvider();
    const firestore = getFirestore(getApp());
    try {
        const result = await signInWithPopup(auth, provider);
        const user = result.user;

        const profileDocRef = doc(firestore, 'users', user.uid, 'profile', 'main-profile');
        const docSnap = await getDoc(profileDocRef);

        if (!docSnap.exists()) {
            // This is a new user, create their profile
            const newProfile = {
                id: profileDocRef.id,
                userId: user.uid,
                fullName: user.displayName || 'New User',
                email: user.email,
                role: 'user', // Default role
                yearsOfExperience: 0,
                currentOrLastJobTitle: "",
                keySkills: [],
                workModePreference: "remote",
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp(),
                profileCompletenessScore: 20
            };
            await setDoc(profileDocRef, newProfile);
            toast({
                title: "Account Created!",
                description: "Welcome to CareerPilot AI.",
            });
        } else {
             toast({
                title: "Welcome Back!",
                description: "You've been successfully logged in.",
            });
        }
    } catch (error: any) {
        toast({
            variant: "destructive",
            title: "Google Sign-In Failed",
            description: error.message || "Could not sign in with Google. Please try again.",
        });
    } finally {
        setIsLoading(false);
    }
  };


  // Don't render the form if we are still checking auth state
  if (isUserLoading || user) {
    return null; 
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
      <Card className="mx-auto max-w-sm w-full shadow-2xl border-none">
        <CardHeader className="text-center pt-8">
          <div className="mx-auto h-12 w-12 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
            <Rocket className="h-6 w-6 text-primary" />
          </div>
          <CardTitle className="text-3xl font-bold font-headline">Get Started</CardTitle>
          <CardDescription className="text-sm">
            Join thousands of professionals using CareerPilot AI.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pb-8">
          <form onSubmit={handleSignup} className="space-y-4">
            <div className="grid gap-2">
                <Label htmlFor="full-name">Full Name</Label>
                <Input 
                  id="full-name" 
                  placeholder="Ada Lovelace" 
                  required 
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  disabled={isLoading}
                  className="bg-slate-50/50"
                />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="m@example.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                className="bg-slate-50/50"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Password</Label>
              <Input 
                id="password" 
                type="password" 
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                className="bg-slate-50/50"
              />
            </div>

            {SITE_CONFIG.security.recaptchaSiteKey && (
                <div className="flex justify-center pt-2">
                    <ReCAPTCHA
                        sitekey={SITE_CONFIG.security.recaptchaSiteKey}
                        onChange={onCaptchaChange}
                    />
                </div>
            )}

            <Button type="submit" className="w-full h-11 text-base font-semibold" disabled={isLoading || (!!SITE_CONFIG.security.recaptchaSiteKey && !captchaToken)}>
              {isLoading ? 'Creating Account...' : 'Create Account'}
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-muted-foreground">Or continue with</span>
            </div>
          </div>

          <Button variant="outline" className="w-full h-11" type="button" onClick={handleGoogleSignup} disabled={isLoading}>
            <svg className="mr-2 h-4 w-4" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512"><path fill="currentColor" d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"></path></svg>
            Sign up with Google
          </Button>

          <div className="text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link href="/login" className="text-primary font-semibold hover:underline">
              Sign in
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
